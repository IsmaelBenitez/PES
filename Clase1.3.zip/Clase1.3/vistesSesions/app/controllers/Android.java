package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Android extends Controller {

	
   /* public static void Login(String n, String p){
        User u = User.Find("byNomAndPassword",n,p).first();
	if(u!=null){
		 renderText("0");
	}else{
		renderText("-1");
	}
	
    }
*/
    
}
