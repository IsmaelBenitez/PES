package com.example.pes_p;
import androidx.appcompat.app.AppCompatActivity;
import com.example.pes_p.R;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class MainActivity2 extends AppCompatActivity{

    private EditText editText;
    private EditText editTextP;
    private Button button;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            editText
                    = (EditText)findViewById(R.id.editTextTextPersonName);
            editTextP
                    = (EditText)findViewById(R.id.editTextTextPassword);
            button
                    = (Button)findViewById(R.id.button);

        if (android.os.Build.VERSION.SDK_INT > 9) {
          StrictMode.ThreadPolicy gfgPolicy =
                  new StrictMode.ThreadPolicy.Builder().permitAll().build();
          StrictMode.setThreadPolicy(gfgPolicy);
        }
//
//        Log.i("Debug :" ,"Debug");
//        TextView n = findViewById (R.id.debugText);
//        n.setText("Iniciem la connexió");
//
//        try {
//        InputStream stream = null;
//
//        n.setText("Iniciem la connexió- enviant petició");
//        String query = "http://192.168.1.145:9000/Android/Login";
//        //String query = String.format("http://10.192.171.29:9000/Application/hello");
//        URL url = new URL(query);
//        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//        conn.setReadTimeout(10000 );
//        conn.setConnectTimeout(15000 /* milliseconds */);
//        conn.setRequestMethod("POST");
//        conn.setDoInput(true);
//        conn.setDoOutput(true);
//        conn.connect();
//
//        //send parameters in message body
//        String params = "Usuari=lola&pass=lolap";
//        OutputStream os = conn.getOutputStream();
//        BufferedWriter writer = new BufferedWriter(
//                new OutputStreamWriter(os, "UTF-8"));
//        writer.write(params);
//        writer.flush();
//        writer.close();
//        os.close();
//
//        n.setText("Esperant resposta  ");
//        //receive response from server
//        stream = conn.getInputStream();
//        BufferedReader reader;
//        StringBuilder sb = new StringBuilder();
//        reader = new BufferedReader(new InputStreamReader(stream));
//        String line;
//        while ((line = reader.readLine()) != null) {
//            sb.append(line);
//        }
//
//        n.setText("Resposta rebuda  " + sb);
//
//        } catch (Exception e) {
//
//            n.setText("Excepcio! " + e);
//            e.printStackTrace();
//        }

        }
    private void startGame() {
        Intent i = new Intent(this, ActivityPage.class);
        startActivity(i);
    }
    public void SendData(View view) {
            new Thread(new Runnable() {
                InputStream stream = null;
                String str = "";
                String result = null;

                public void run() {
                    Log.i("Debug :", "Debug");

                    try {
                        InputStream stream = null;

                        String query = "http://192.168.1.144:9000/Android/Login";
                        //  BUSCAR LA IP DEL ORDENADOR     String query = String.format("http://10.192.171.29:9000/Application/hello");
                        URL url = new URL(query);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setReadTimeout(10000);
                        conn.setConnectTimeout(15000 /* milliseconds */);
                        conn.setRequestMethod("POST");
                        conn.setDoInput(true);
                        conn.setDoOutput(true);
                        conn.connect();

                        //send parameters in message body
                        String name
                                = editText.getText()
                                .toString();
                        String password
                                = editTextP.getText()
                                .toString();
                        String params = "nombre="+name+"&password="+password;
                        OutputStream os = conn.getOutputStream();
                        BufferedWriter writer = new BufferedWriter(
                                new OutputStreamWriter(os, "UTF-8"));
                        writer.write(params);
                        writer.flush();
                        writer.close();
                        os.close();

                        // n.setText("Esperant resposta  thread");
                        //receive response from server
                        stream = conn.getInputStream();
                        BufferedReader reader;
                        StringBuilder sb = new StringBuilder();
                        reader = new BufferedReader(new InputStreamReader(stream));
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        // n.setText("Resposta rebuda  thread" + sb);

                        //TextView n2 = findViewById(R.id.debugText);
                        TextView n = findViewById(R.id.button);//Porque va y el debugText no?

                        n.post(new Runnable() {
                            public void run() {
                                //n.setText("Resposta rebuda  thread" + sb);
                                Gson gson = new Gson();
                                try {
                                    JsonArray llistaUsusaris = new JsonParser().parse(String.valueOf(sb)).getAsJsonArray();
                                    String s = "Noms ";
                                    int x=0;
                                    for (int i = 0; i < llistaUsusaris.size(); i++) {
                                        JsonObject json = (JsonObject) llistaUsusaris.get(i);
                                        //Aquí se obtiene el dato y es guardado en una lista
                                        s=s + json.get("password");
                                        x=x+1;
                                    }
                                    if(x>0)
                                    startGame();
                                    else
                                    {
                                        n.setText("Registrate abajo");
                                    }

                                    //Intent intent = new Intent(MainActivity2.this,
                                          //  ActivityPage.class);
                                   // intent/.putExtra("Text",s);
                                    //startActivity(intent);
                                    //n.setText("Resposta rebuda thread" + s);
                                } catch(JsonIOException e){
                                    n.setText("Error thread" + e);
                                    e.printStackTrace();
                                }
                            }
                        });

                    } catch (Exception e) {
                        TextView n = findViewById(R.id.button);
                        n.post(new Runnable() {
                            public void run() {
                                n.setText("Resposta rebuda  thread" + e);
                            }
                        });
                        e.printStackTrace();
                    }
                }
            }).start();



        }
    public void SendDataR(View view) {
        new Thread(new Runnable() {
            InputStream stream = null;
            String str = "";
            String result = null;
            public void run() {
                Log.i("Debug :", "Debug");

                try {
                    Register();
                } catch (Exception e) {
                }
            }
        }).start();
    }
    private void Register() {
        Intent i = new Intent(this, ActivityRegister.class);
        startActivity(i);
    }
    }