package com.example.pes_p;

import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class ActivityRegister extends AppCompatActivity{

    private EditText nombre;
    private EditText edad;
    private EditText password;
    private Button button;
    private Button buttonV;


    @Override

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_register);
        nombre
                = (EditText)findViewById(R.id.Nombre);
        edad
                = (EditText)findViewById(R.id.Edad);
        password
                = (EditText)findViewById(R.id.Password);
        button
                = (Button)findViewById(R.id.Registrarse);
        buttonV
                = (Button)findViewById(R.id.Volver);
        }

    public void SendData(View view) {
        new Thread(new Runnable() {
            InputStream stream = null;
            String str = "";
            String result = null;

            public void run() {
                Log.i("Debug :", "Debug");

                try {
                    InputStream stream = null;

                    String query = "http://192.168.1.144:9000/Android/Register";
                    //  BUSCAR LA IP DEL ORDENADOR     String query = String.format("http://10.192.171.29:9000/Application/hello");
                    URL url = new URL(query);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setReadTimeout(10000);
                    conn.setConnectTimeout(15000 /* milliseconds */);
                    conn.setRequestMethod("POST");
                    conn.setDoInput(true);
                    conn.setDoOutput(true);
                    conn.connect();

                    //send parameters in message body
                    String name
                            = nombre.getText()
                            .toString();
                    String ed
                            = edad.getText()
                            .toString();
                    String pass
                            = password.getText()
                            .toString();
                    String params = "nombre="+name+"&edad="+ed+"&password="+pass;
                    OutputStream os = conn.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(params);
                    writer.flush();
                    writer.close();
                    os.close();

                    // n.setText("Esperant resposta  thread");
                    //receive response from server
                    stream = conn.getInputStream();
                    BufferedReader reader;
                    StringBuilder sb = new StringBuilder();
                    reader = new BufferedReader(new InputStreamReader(stream));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    // n.setText("Resposta rebuda  thread" + sb);

                    //TextView n2 = findViewById(R.id.debugText);
                    TextView n = findViewById(R.id.button);//Porque va y el debugText no?

                    n.post(new Runnable() {
                        public void run() {
                            //n.setText("Resposta rebuda  thread" + sb);
                            Gson gson = new Gson();
                            try {
                                JsonArray llistaUsusaris = new JsonParser().parse(String.valueOf(sb)).getAsJsonArray();
                                String s = "Noms ";
                                int x=0;
                                for (int i = 0; i < llistaUsusaris.size(); i++) {
                                    JsonObject json = (JsonObject) llistaUsusaris.get(i);
                                    //Aquí se obtiene el dato y es guardado en una lista
                                    s=s + json.get("password");
                                    x=x+1;
                                }
                                if(x>0)
                                    startGame();
                                else
                                {
                                    n.setText("Usuario existente");
                                }

                                //Intent intent = new Intent(MainActivity2.this,
                                //  ActivityPage.class);
                                // intent/.putExtra("Text",s);
                                //startActivity(intent);
                                //n.setText("Resposta rebuda thread" + s);
                            } catch(JsonIOException e){
                                n.setText("Error thread" + e);
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (Exception e) {
                    TextView n = findViewById(R.id.button);
                    n.post(new Runnable() {
                        public void run() {
                            n.setText("Resposta rebuda  thread" + e);
                        }
                    });
                    e.printStackTrace();
                }
            }
        }).start();
    }
    private void startGame() {
        Intent i = new Intent(this, ActivityPage.class);
        startActivity(i);
    }
    private void Return() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
    public void Volver(View view) {
        new Thread(new Runnable() {
            InputStream stream = null;
            String str = "";
            String result = null;
            public void run() {
                Log.i("Debug :", "Debug");

                try {
                    Return();
                } catch (Exception e) {
                }
            }
        }).start();
    }

}
