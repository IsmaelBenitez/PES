# PES


Test es la carpeta con apuntes y con lo que tenemos que hacer

La otra carpeta contiene el código
