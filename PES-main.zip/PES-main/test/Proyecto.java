public class Proyecto {
/*
    Relaciones:
        Form-Asignatura: 1-1
        Form-Mensaje: 1:N --
        Usuarios-Mensaje: 1:N --
        Usuarios-Asignaruta: N-M --

        Peticiones:
            1) Buscar si existe un foro
            2) Obtener los datos del foro
            3) Buscar personas que tengan la signatura escrita
            4) Buscar que asignaturas hace una persona
            5) Buscar los forums con una etiqueta el asunto
            6) Determinar en una lsita cuantas personas hay en todos los forums (se puede ordenar)
*/
}
